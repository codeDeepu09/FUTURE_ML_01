# FUTURE_ML_01 — AI-Powered Sales Forecasting Dashboard

This repository implements **Task 1** for the Future Interns Machine Learning track.

## 🔧 What’s inside
- **notebooks/01_forecasting.ipynb**: A guided notebook that loads retail sales data, explores it, trains a baseline model, and produces a forecast and plots.
- **src/train_forecast.py**: A CLI script to train a simple regression-based time-series model and export `reports/forecast.csv` and plots to `reports/figures/`.
- **data/raw/sample_sales.csv**: A small synthetic dataset (monthly) you can use if you don't have a dataset.
- **powerbi/**: Placeholder folder for your Power BI `.pbix` file. Export your final visuals to images and place them in `reports/figures/` too.

## 🧰 Recommended stack
Python, Pandas, NumPy, Scikit-learn, Matplotlib, (optional) Prophet/Statsmodels, and Power BI for the dashboard.

## 🚀 Quickstart
```bash
# 1) Create a virtual environment (optional but recommended)
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate

# 2) Install dependencies
pip install -r requirements.txt

# 3) Run the notebook
jupyter notebook notebooks/01_forecasting.ipynb

# 4) Or run the CLI script on a CSV (date,sales)
python src/train_forecast.py --csv data/raw/sample_sales.csv --horizon 6
```

The script saves outputs to:
- `reports/forecast.csv` — future dates with predicted sales
- `reports/figures/forecast_plot.png` — forecast visualization

## 🗂️ Expected data format
Your CSV should have at least:
```
date,sales
2022-01-01,1200
2022-02-01,1350
...
```
- `date`: daily/weekly/monthly (ISO format preferred)
- `sales`: numeric

## 📊 Power BI
1. Load `reports/forecast.csv` (and your original metrics) into Power BI.
2. Create visuals to show **trend**, **seasonality**, and **forecast**.
3. Export final images to `reports/figures/` and commit the `.pbix` to `powerbi/`.

## 🧪 Re-running with your data
Replace `data/raw/sample_sales.csv` with your dataset (same columns). Tweak notebook cells or `src/train_forecast.py` parameters as needed.

## 📝 Submission & LinkedIn
- **Repo name rule:** `FUTURE_ML_01`
- **Make a LinkedIn post** after you finish. See the template in this README’s bottom section.
- **Task Submission Form:** submit when Future Interns share the form link.

## 🐙 GitHub (first-time setup)
```bash
# Initialize repo and make first commit
git init
git add .
git commit -m "Init: Future Interns ML Task 1 starter"

# Create GitHub repo named FUTURE_ML_01, then:
git branch -M main
git remote add origin https://github.com/<your-username>/FUTURE_ML_01.git
git push -u origin main
```

## ✅ Checklist
- [ ] Proper repo name: `FUTURE_ML_01`
- [ ] Clean README with screenshots
- [ ] Notebook runs top-to-bottom without errors
- [ ] `reports/forecast.csv` generated
- [ ] Power BI visuals saved in `reports/figures/`
- [ ] Meaningful commit messages
- [ ] LinkedIn post created (tag #FutureInterns, add visuals)

---

## 📣 LinkedIn Post Template
**Title:** Finished Task 1 — AI-Powered Sales Forecasting Dashboard 🚀

I just completed Task 1 of my Machine Learning internship at Future Interns!
**What I did:** Built a forecasting pipeline on retail sales data and created an interactive dashboard.
**Key skills:** time series forecasting, regression, feature engineering, visualization.
**Tools:** Python (Pandas, Scikit-learn, Matplotlib), Power BI.

**Results:** Forecast shows the next N periods with visible trend/seasonality and confidence band.
**Repo:** 👉 github.com/<your-username>/FUTURE_ML_01

Thanks to #FutureInterns for the opportunity!

(Optionally add a short demo video.)

---

## 📄 License
This project uses the MIT License (see `LICENSE`).
