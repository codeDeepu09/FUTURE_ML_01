#!/usr/bin/env python3
"""
Train a simple regression-based forecasting model on time-indexed sales data.

Usage:
  python src/train_forecast.py --csv data/raw/sample_sales.csv --horizon 6
"""
import argparse
from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

def load_data(csv_path: Path) -> pd.DataFrame:
    df = pd.read_csv(csv_path, parse_dates=["date"])
    df = df.sort_values("date").reset_index(drop=True)
    if "sales" not in df.columns:
        raise ValueError("CSV must have a 'sales' column.")
    return df

def add_time_index(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["t"] = (df["date"] - df["date"].min()).dt.days
    return df

def train_and_forecast(df: pd.DataFrame, horizon: int = 6) -> pd.DataFrame:
    df = add_time_index(df)
    X = df[["t"]].values
    y = df["sales"].values
    model = LinearRegression().fit(X, y)

    # Build future horizon
    freq = pd.infer_freq(df["date"]) or "MS"
    last_date = df["date"].max()
    future_dates = pd.date_range(start=last_date + pd.tseries.frequencies.to_offset(freq), periods=horizon, freq=freq)

    # approximate step in days for time index
    median_step = int(df["date"].diff().dt.days.dropna().median() or 30)
    max_t = df["t"].max()
    future_t = np.arange(max_t + median_step, max_t + (horizon+1)*median_step, median_step)[:horizon]

    preds = model.predict(future_t.reshape(-1, 1))
    forecast = pd.DataFrame({"date": future_dates, "forecast": preds.round(0).astype(int)})
    return forecast

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", type=str, required=True, help="Path to CSV with columns: date,sales")
    parser.add_argument("--horizon", type=int, default=6, help="Forecast horizon (periods)")
    args = parser.parse_args()

    df = load_data(Path(args.csv))
    forecast = train_and_forecast(df, args.horizon)

    out_dir = Path("reports")
    fig_dir = out_dir / "figures"
    fig_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "forecast.csv"
    forecast.to_csv(out_path, index=False)

    # quick plot
    plt.figure()
    plt.plot(df["date"], df["sales"], label="history")
    plt.plot(forecast["date"], forecast["forecast"], linestyle="--", label="forecast")
    plt.title("Sales Forecast")
    plt.xlabel("Date")
    plt.ylabel("Sales")
    plt.legend()
    plt.savefig(fig_dir / "forecast_plot.png", bbox_inches="tight")

    print(f"Saved forecast to {out_path}")
    print(f"Saved plot to {fig_dir / 'forecast_plot.png'}")

if __name__ == "__main__":
    main()
